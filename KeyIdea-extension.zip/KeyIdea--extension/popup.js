const homePage = document.getElementById("homePage");
const ideasPage = document.getElementById("ideasPage");
const reviewPage = document.getElementById("reviewPage");

const goIdeasBtn = document.getElementById("goIdeasBtn");
const goReviewBtn = document.getElementById("goReviewBtn");

const backFromIdeas = document.getElementById("backFromIdeas");
const backFromReview = document.getElementById("backFromReview");

const toggleFolderBoxBtn = document.getElementById("toggleFolderBoxBtn");
const folderBox = document.getElementById("folderBox");
const folderInput = document.getElementById("folderInput");
const createFolderBtn = document.getElementById("createFolderBtn");

const toggleThemeBoxBtn = document.getElementById("toggleThemeBoxBtn");
const themeBox = document.getElementById("themeBox");
const themeFolderSelect = document.getElementById("themeFolderSelect");
const themeInput = document.getElementById("themeInput");
const createThemeBtn = document.getElementById("createThemeBtn");

const filterSelect = document.getElementById("filterSelect");
const ideaThemeFilter = document.getElementById("ideaThemeFilter");
const clipsContainer = document.getElementById("clips");

const reviewFolderSelect = document.getElementById("reviewFolderSelect");
const themeSearchInput = document.getElementById("themeSearchInput");
const themeSelect = document.getElementById("themeSelect");
const reviewCard = document.getElementById("reviewCard");
const reviewCounter = document.getElementById("reviewCounter");
const prevIdeaBtn = document.getElementById("prevIdeaBtn");
const nextIdeaBtn = document.getElementById("nextIdeaBtn");

let reviewIdeas = [];
let currentReviewIndex = 0;

function showPage(page) {
homePage.classList.add("hidden");
ideasPage.classList.add("hidden");
reviewPage.classList.add("hidden");
page.classList.remove("hidden");
}

function formatDate(isoDate) {
return new Date(isoDate).toLocaleDateString("fr-FR");
}

function normalizeFolders(folders) {
let cleanFolders = folders || ["Général"];
if (!cleanFolders.includes("Général")) cleanFolders.unshift("Général");
return [...new Set(cleanFolders)];
}

function normalizeThemes(themes) {
let cleanThemes = themes || [{ name: "Sans thème", folder: "Général" }];

cleanThemes = cleanThemes.map((theme) => {
if (typeof theme === "string") {
return { name: theme, folder: "Général" };
}
return theme;
});

const hasSansTheme = cleanThemes.some((theme) => theme.name === "Sans thème");

if (!hasSansTheme) {
cleanThemes.unshift({ name: "Sans thème", folder: "Général" });
}

const seen = new Set();

return cleanThemes.filter((theme) => {
const key = `${theme.folder}__${theme.name}`;
if (seen.has(key)) return false;
seen.add(key);
return true;
});
}

function getThemeLabel(theme) {
return `${theme.folder} → ${theme.name}`;
}

function refreshFolderSelectors() {
chrome.storage.local.get(["folders"], (result) => {
const folders = normalizeFolders(result.folders);

chrome.storage.local.set({ folders }, () => {
const currentIdeaFolder = filterSelect.value || "Tous";
const currentReviewFolder = reviewFolderSelect.value || "Tous";
const currentThemeFolder = themeFolderSelect.value || "Général";

filterSelect.innerHTML = `<option value="Tous">Tous les dossiers</option>`;
reviewFolderSelect.innerHTML = `<option value="Tous">Tous les dossiers</option>`;
themeFolderSelect.innerHTML = "";

folders.forEach((folder) => {
const option1 = document.createElement("option");
option1.value = folder;
option1.textContent = folder;
filterSelect.appendChild(option1);

const option2 = document.createElement("option");
option2.value = folder;
option2.textContent = folder;
reviewFolderSelect.appendChild(option2);

const option3 = document.createElement("option");
option3.value = folder;
option3.textContent = `Dossier : ${folder}`;
themeFolderSelect.appendChild(option3);
});

filterSelect.value = folders.includes(currentIdeaFolder) ? currentIdeaFolder : "Tous";
reviewFolderSelect.value = folders.includes(currentReviewFolder) ? currentReviewFolder : "Tous";
themeFolderSelect.value = folders.includes(currentThemeFolder) ? currentThemeFolder : "Général";
});
});
}

function refreshThemeSelectors() {
chrome.storage.local.get(["themes"], (result) => {
const themes = normalizeThemes(result.themes);

chrome.storage.local.set({ themes }, () => {
const currentIdeaTheme = ideaThemeFilter.value || "Tous";
const currentReviewTheme = themeSelect.value || "Tous";

ideaThemeFilter.innerHTML = `<option value="Tous">Tous les thèmes</option>`;
themeSelect.innerHTML = `<option value="Tous">Tous les thèmes</option>`;

themes.forEach((theme) => {
const option1 = document.createElement("option");
option1.value = getThemeLabel(theme);
option1.textContent = getThemeLabel(theme);
ideaThemeFilter.appendChild(option1);

const option2 = document.createElement("option");
option2.value = getThemeLabel(theme);
option2.textContent = getThemeLabel(theme);
themeSelect.appendChild(option2);
});

ideaThemeFilter.value = currentIdeaTheme;
themeSelect.value = currentReviewTheme;
});
});
}

function createFolder() {
const folderName = folderInput.value.trim();
if (!folderName) return;

chrome.storage.local.get(["folders"], (result) => {
let folders = normalizeFolders(result.folders);

if (!folders.includes(folderName)) {
folders.push(folderName);
}

chrome.storage.local.set({ folders }, () => {
folderInput.value = "";
folderBox.classList.add("hidden");
refreshFolderSelectors();
chrome.runtime.sendMessage({ type: "refresh-menus" });
});
});
}

function createTheme() {
const themeName = themeInput.value.trim();
const folderName = themeFolderSelect.value || "Général";

if (!themeName) return;

chrome.storage.local.get(["themes"], (result) => {
let themes = normalizeThemes(result.themes);

const exists = themes.some(
(theme) => theme.name === themeName && theme.folder === folderName
);

if (!exists) {
themes.push({ name: themeName, folder: folderName });
}

chrome.storage.local.set({ themes }, () => {
themeInput.value = "";
themeBox.classList.add("hidden");
refreshThemeSelectors();
displayClips();
loadReviewIdeas();
});
});
}

function updateClipTheme(index, themeLabel) {
chrome.storage.local.get(["clips"], (result) => {
const clips = result.clips || [];
if (!clips[index]) return;

clips[index].theme = themeLabel;

chrome.storage.local.set({ clips }, () => {
displayClips();
loadReviewIdeas();
});
});
}

function displayClips() {
chrome.storage.local.get(["clips", "themes"], (result) => {
const allClips = result.clips || [];
const themes = normalizeThemes(result.themes);

let clipsWithIndex = allClips.map((clip, index) => ({
...clip,
originalIndex: index,
theme: clip.theme || "Général → Sans thème"
}));

const folderFilter = filterSelect.value || "Tous";
const themeFilter = ideaThemeFilter.value || "Tous";

if (folderFilter !== "Tous") {
clipsWithIndex = clipsWithIndex.filter((clip) => clip.folder === folderFilter);
}

if (themeFilter !== "Tous") {
clipsWithIndex = clipsWithIndex.filter((clip) => clip.theme === themeFilter);
}

clipsContainer.innerHTML = "";

if (clipsWithIndex.length === 0) {
clipsContainer.innerHTML = `<p class="empty">Aucune grande idée ici.</p>`;
return;
}

clipsWithIndex.forEach((clip) => {
const card = document.createElement("div");
card.className = "clip-card";

const themeOptions = themes
.map((theme) => {
const label = getThemeLabel(theme);
const selected = clip.theme === label ? "selected" : "";
return `<option value="${label}" ${selected}>${label}</option>`;
})
.join("");

card.innerHTML = `
<p class="folder">${clip.folder || "Général"}</p>
<select class="theme-picker" data-index="${clip.originalIndex}">
${themeOptions}
</select>
<p class="clip-text">“${clip.text}”</p>
<p class="clip-meta">Sauvegardé le ${formatDate(clip.date)}</p>
<p class="review">Rappel : ${formatDate(clip.reviewDate)}</p>
<p class="clip-source">${clip.title || "Source inconnue"}</p>
`;

clipsContainer.appendChild(card);
});

document.querySelectorAll(".theme-picker").forEach((select) => {
select.addEventListener("change", (event) => {
updateClipTheme(Number(event.target.dataset.index), event.target.value);
});
});
});
}

function loadReviewIdeas() {
chrome.storage.local.get(["clips"], (result) => {
let clips = (result.clips || []).map((clip) => ({
...clip,
theme: clip.theme || "Général → Sans thème"
}));

const selectedFolder = reviewFolderSelect.value || "Tous";
const selectedTheme = themeSelect.value || "Tous";
const search = themeSearchInput.value.trim().toLowerCase();

if (selectedFolder !== "Tous") {
clips = clips.filter((clip) => clip.folder === selectedFolder);
}

if (selectedTheme !== "Tous") {
clips = clips.filter((clip) => clip.theme === selectedTheme);
}

if (search) {
clips = clips.filter((clip) =>
(clip.theme || "").toLowerCase().includes(search) ||
(clip.text || "").toLowerCase().includes(search) ||
(clip.folder || "").toLowerCase().includes(search)
);
}

reviewIdeas = clips;
currentReviewIndex = 0;
displayCurrentReviewIdea();
});
}

function displayCurrentReviewIdea() {
if (reviewIdeas.length === 0) {
reviewCounter.textContent = "0 / 0";
reviewCard.innerHTML = `<p class="empty">Aucune idée à afficher pour ce filtre.</p>`;
return;
}

const clip = reviewIdeas[currentReviewIndex];

reviewCounter.textContent = `${currentReviewIndex + 1} / ${reviewIdeas.length}`;

reviewCard.innerHTML = `
<p class="folder">${clip.folder || "Général"}</p>
<p class="theme">${clip.theme || "Général → Sans thème"}</p>
<p class="big-idea">“${clip.text}”</p>
<p class="clip-meta">Sauvegardé le ${formatDate(clip.date)}</p>
<p class="review">Rappel : ${formatDate(clip.reviewDate)}</p>
<p class="clip-source">${clip.title || "Source inconnue"}</p>
`;
}

function nextIdea() {
if (reviewIdeas.length === 0) return;
currentReviewIndex = (currentReviewIndex + 1) % reviewIdeas.length;
displayCurrentReviewIdea();
}

function previousIdea() {
if (reviewIdeas.length === 0) return;
currentReviewIndex = (currentReviewIndex - 1 + reviewIdeas.length) % reviewIdeas.length;
displayCurrentReviewIdea();
}

goIdeasBtn.addEventListener("click", () => {
showPage(ideasPage);
refreshFolderSelectors();
refreshThemeSelectors();
displayClips();
});

goReviewBtn.addEventListener("click", () => {
showPage(reviewPage);
refreshFolderSelectors();
refreshThemeSelectors();
loadReviewIdeas();
});

backFromIdeas.addEventListener("click", () => showPage(homePage));
backFromReview.addEventListener("click", () => showPage(homePage));

toggleFolderBoxBtn.addEventListener("click", () => {
folderBox.classList.toggle("hidden");
});

toggleThemeBoxBtn.addEventListener("click", () => {
themeBox.classList.toggle("hidden");
});

createFolderBtn.addEventListener("click", createFolder);
createThemeBtn.addEventListener("click", createTheme);

folderInput.addEventListener("keydown", (event) => {
if (event.key === "Enter") createFolder();
});

themeInput.addEventListener("keydown", (event) => {
if (event.key === "Enter") createTheme();
});

filterSelect.addEventListener("change", displayClips);
ideaThemeFilter.addEventListener("change", displayClips);

reviewFolderSelect.addEventListener("change", loadReviewIdeas);
themeSearchInput.addEventListener("input", loadReviewIdeas);
themeSelect.addEventListener("change", loadReviewIdeas);

nextIdeaBtn.addEventListener("click", nextIdea);
prevIdeaBtn.addEventListener("click", previousIdea);

refreshFolderSelectors();
refreshThemeSelectors();


