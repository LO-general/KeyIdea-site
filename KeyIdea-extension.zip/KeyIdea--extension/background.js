function addDays(days) {
    const date = new Date();
    date.setDate(date.getDate() + Number(days));
    return date.toISOString();
    }
    
    function safeMenuId(folder) {
    return "folder-" + encodeURIComponent(folder);
    }
    
    function folderFromMenuId(menuId) {
    return decodeURIComponent(menuId.replace("folder-", ""));
    }
    
    function createMenus(folders) {
    chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
    id: "save-root",
    title: "Save to Key Idea",
    contexts: ["selection"]
    });
    
    folders.forEach((folder) => {
    chrome.contextMenus.create({
    id: safeMenuId(folder),
    parentId: "save-root",
    title: folder,
    contexts: ["selection"]
    });
    });
    });
    }
    
    function refreshMenus() {
    chrome.storage.local.get(["folders"], (result) => {
    let folders = result.folders || ["Général"];
    
    if (!folders.includes("Général")) {
    folders.unshift("Général");
    }
    
    folders = [...new Set(folders)];
    
    chrome.storage.local.set({ folders }, () => {
    createMenus(folders);
    });
    });
    }
    
    chrome.runtime.onInstalled.addListener(refreshMenus);
    chrome.runtime.onStartup.addListener(refreshMenus);
    
    chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (!String(info.menuItemId).startsWith("folder-")) return;
    
    const folder = folderFromMenuId(info.menuItemId);
    
    const newClip = {
    text: info.selectionText,
    folder,
    theme: "Sans thème",
    url: tab?.url || "",
    title: tab?.title || "",
    date: new Date().toISOString(),
    reviewDate: addDays(30)
    };
    
    chrome.storage.local.get(["clips"], (result) => {
    const clips = result.clips || [];
    clips.unshift(newClip);
    chrome.storage.local.set({ clips });
    });
    });
    
    chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "refresh-menus") {
    refreshMenus();
    }
    });
    